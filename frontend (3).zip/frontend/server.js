const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const multer = require('multer');
const csvParser = require('csv-parser');
const fs = require('fs');
const upload = multer({ dest: 'uploads/' });

const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'oalizo',
    password: '',
    port: 5432,
});

// Rota para buscar produtos
app.get('/produtos', async (req, res) => {
    try {
        const { rows } = await pool.query("SELECT * FROM produtos");
        console.log("Produtos enviados com sucesso.");
        res.json({
            "message": "success",
            "data": rows
        });
    } catch (err) {
        console.error("Erro ao buscar produtos: ", err.message);
        res.status(400).json({ "error": err.message });
    }
});

// Rota para deletar um produto específico
app.delete('/produto/:sku', async (req, res) => {
    console.log(`Requisição DELETE em /produto/${req.params.sku}`);
    const { sku } = req.params;

    if (!sku || sku === 'undefined') {
        console.log("SKU não fornecido ou é 'undefined'.");
        return res.status(400).json({ message: "SKU inválido." });
    }

    try {
        const result = await pool.query('DELETE FROM produtos WHERE sku2 = $1', [sku]);
        if (result.rowCount > 0) {
            console.log(`Produto com SKU ${sku} deletado com sucesso.`);
            res.json({ message: 'Produto deletado com sucesso' });
        } else {
            console.log(`Produto com SKU ${sku} não encontrado.`);
            res.status(404).json({ message: 'Produto não encontrado' });
        }
    } catch (err) {
        console.error("Erro ao deletar produto: ", err.message);
        res.status(400).json({ "error": err.message });
    }
});


// Rota para upload e exclusão de produtos via CSV
app.post('/upload-csv', upload.single('csv'), (req, res) => {
    console.log("Recebendo requisição POST em /upload-csv");
    const skusToDelete = [];
    fs.createReadStream(req.file.path)
        .pipe(csvParser())
        .on('data', (row) => {
            const sku = row["SKU"] || row["Sku"] || row["sku"];
            if (sku) {
                skusToDelete.push(sku.trim());
            }
        })
        .on('end', async () => {
            fs.unlinkSync(req.file.path); // Removendo o arquivo CSV após o processamento
            if (skusToDelete.length > 0) {
                const query = 'DELETE FROM produtos WHERE sku2 = ANY($1)';
                try {
                    const result = await pool.query(query, [skusToDelete]);
                    console.log(`${result.rowCount} produtos foram excluídos.`);
                    res.json({ message: `${result.rowCount} produtos excluídos` });
                } catch (err) {
                    console.error("Erro ao deletar produtos por SKU: ", err.message);
                    res.status(500).json({ message: 'Erro ao excluir produtos', error: err.message });
                }
            } else {
                console.log("Nenhum SKU para deletar.");
                res.json({ message: "Nenhum SKU fornecido para exclusão." });
            }
        });
});



app.post('/delete-multiple', async (req, res) => {
    const skusToDelete = req.body.skus;
    console.log('SKUs recebidos para exclusão:', skusToDelete);

    if (skusToDelete.length === 0) {
        return res.status(400).json({ message: 'Nenhum SKU fornecido para exclusão.' });
    }

    try {
        const query = 'DELETE FROM produtos WHERE sku2 = ANY($1::text[])';
        const { rowCount } = await pool.query(query, [skusToDelete]);
        console.log(`${rowCount} produtos foram excluídos.`);
        res.json({ message: `${rowCount} produtos excluídos` });
    } catch (err) {
        console.error('Erro ao excluir produtos:', err);
        res.status(500).json({ error: err.message });
    }
});




app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
