window.onload = function() {
    fetchProdutosEAtualizarTabela();
    document.getElementById('filter-sku').addEventListener('keyup', applyFilters);
    document.getElementById('filter-asin').addEventListener('keyup', applyFilters);
    document.getElementById('filter-availability').addEventListener('keyup', applyFilters);
    document.getElementById('filter-lead-time').addEventListener('keyup', applyFilters);
    document.getElementById('filter-brand').addEventListener('keyup', applyFilters);
};

function fetchProdutosEAtualizarTabela() {
    fetch('/produtos')
        .then(response => response.json())
        .then(data => {
            const table = document.getElementById('productTable');
            renderTableRows(data.data, table);
            atualizarContagemProdutos(data.data.length);
        });
}

function renderTableRows(data, table) {
    table.innerHTML = '';
    data.forEach(product => {
        const row = table.insertRow();
        row.setAttribute('data-sku', product.sku2);
        
        const selectCell = row.insertCell();
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.setAttribute('data-rowid', product.rowid);
        selectCell.appendChild(checkbox);

        const skuCell = row.insertCell();
        const skuLink = document.createElement('a');
        skuLink.href = `https://www.zoro.com/i/${product.sku}/?q=${product.sku}`;
        skuLink.textContent = product.sku2;
        skuLink.target = "_blank";
        skuCell.appendChild(skuLink);

        const asinCell = row.insertCell();
        const asinLink = document.createElement('a');
        asinLink.href = `https://www.amazon.com/dp/${product.asin}`;
        asinLink.textContent = product.asin;
        asinLink.target = "_blank";
        asinCell.appendChild(asinLink);

        row.insertCell().textContent = product.freight_cost || '';
        row.insertCell().textContent = product.price_with_increase || '';
        row.insertCell().textContent = product.total_price || '';
        row.insertCell().textContent = product.lead_time || '';
        row.insertCell().textContent = product.availability || '';
        row.insertCell().textContent = product.quantity || '';
        row.insertCell().textContent = product.last_update || '';
        row.insertCell().textContent = product.brand || '';

        const actionCell = row.insertCell();
        actionCell.innerHTML = `<i class="fas fa-edit" style="cursor: pointer;" onclick="editProduct(${product.rowid})"></i> <i class="fas fa-trash" style="cursor: pointer;" onclick="deleteProduct(${product.rowid}, '${product.sku2}', this)"></i>`;
    });
}

function applyFilters() {
    const skuValue = document.getElementById('filter-sku').value.toLowerCase();
    const asinValue = document.getElementById('filter-asin').value.toLowerCase();
    const availabilityValue = document.getElementById('filter-availability').value.toLowerCase();
    const leadTimeValue = document.getElementById('filter-lead-time').value.toLowerCase();
    const brandValue = document.getElementById('filter-brand').value.toLowerCase();

    fetch('/produtos')
        .then(response => response.json())
        .then(data => {
            let filteredData = data.data;
            filteredData = filteredData.filter(product => product.sku2.toLowerCase().includes(skuValue));
            filteredData = filteredData.filter(product => product.asin.toLowerCase().includes(asinValue));
            filteredData = filteredData.filter(product => product.availability.toLowerCase().includes(availabilityValue));
            filteredData = filteredData.filter(product => product.lead_time.toLowerCase().includes(leadTimeValue));
            filteredData = filteredData.filter(product => product.brand.toLowerCase().includes(brandValue));
            const table = document.getElementById('productTable');
            renderTableRows(filteredData, table);
            atualizarContagemProdutos(filteredData.length);
        });
}

function atualizarContagemProdutos(count) {
    document.getElementById('total-produtos').textContent = count;
}

function deleteProduct(rowid, sku, element) {
    if (confirm('Tem certeza que deseja excluir este produto do banco de dados local?')) {
        let deleteFromAmazon = confirm('Deseja também excluir este produto da Amazon?');
        fetch(`/produto/${rowid}`, {
            method: 'DELETE',
        })
        .then(response => response.json())
        .then(() => {
            console.log(`Produto com rowid ${rowid} excluído do banco de dados`);
            if (deleteFromAmazon) {
                deleteProductFromAmazon(sku);
            }
            const row = element.parentNode.parentNode;
            row.parentNode.removeChild(row);
        })
        .catch(error => console.error('Erro ao excluir o produto do banco de dados:', error));
    }
}

function deleteProductFromAmazon(sku) {
    fetch('/api/amazon/delete-product', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ sku }),
    })
    .then(response => response.json())
    .then(data => {
        console.log(`Produto com SKU ${sku} excluído da Amazon`, data);
    })
    .catch(error => {
        console.error(`Erro ao excluir o produto com SKU ${sku} da Amazon`, error);
    });
}
