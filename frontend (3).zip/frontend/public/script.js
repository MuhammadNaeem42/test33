window.onload = function() {
    fetchProdutosEAtualizarTabela();
    document.getElementById('filter-sku').addEventListener('keyup', applyFilters);
    document.getElementById('filter-asin').addEventListener('keyup', applyFilters);
    document.getElementById('filter-availability').addEventListener('keyup', applyFilters);
    document.getElementById('filter-lead-time').addEventListener('keyup', applyFilters);
    document.getElementById('filter-brand').addEventListener('keyup', applyFilters);
};

function fetchProdutosEAtualizarTabela() {
    fetch('/produtos')
        .then(response => response.json())
        .then(data => {
            const table = document.getElementById('productTable');
            renderTableRows(data.data, table);
            atualizarContagemProdutos(data.data.length);
        })
        .catch(error => console.error("Erro ao buscar produtos: ", error));
}

function renderTableRows(data, table) {
    table.innerHTML = '';
    data.forEach(product => {
        const row = table.insertRow();

        const selectCell = row.insertCell();
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.setAttribute('data-sku', product.sku2);
        selectCell.appendChild(checkbox);

        const skuCell = row.insertCell();
        skuCell.textContent = product.sku2;

        const asinCell = row.insertCell();
        asinCell.textContent = product.asin;

        const freightCostCell = row.insertCell();
        freightCostCell.textContent = product.freight_cost;

        const priceWithIncreaseCell = row.insertCell();
        priceWithIncreaseCell.textContent = product.price_with_increase;

        const totalPriceCell = row.insertCell();
        totalPriceCell.textContent = product.total_price;

        const leadTimeCell = row.insertCell();
        leadTimeCell.textContent = product.lead_time;

        const availabilityCell = row.insertCell();
        availabilityCell.textContent = product.availability;

        const quantityCell = row.insertCell();
        quantityCell.textContent = product.quantity;

        const brandCell = row.insertCell();
        brandCell.textContent = product.brand;

        const lastUpdateCell = row.insertCell();
        lastUpdateCell.textContent = product.last_update;

        const actionCell = row.insertCell();
        actionCell.innerHTML = `<i class="fas fa-edit" style="cursor: pointer;" onclick="editProduct('${product.sku2}')"></i> <i class="fas fa-trash" style="cursor: pointer;" onclick="deleteProduct('${product.sku2}', this)"></i>`;
    });
}

function applyFilters() {
    const skuValue = document.getElementById('filter-sku').value.toLowerCase();
    const asinValue = document.getElementById('filter-asin').value.toLowerCase();
    const availabilityValue = document.getElementById('filter-availability').value.toLowerCase();
    const leadTimeValue = document.getElementById('filter-lead-time').value.toLowerCase();
    const brandValue = document.getElementById('filter-brand').value.toLowerCase();

    fetch('/produtos')
        .then(response => response.json())
        .then(data => {
            let filteredData = data.data;
            if (skuValue) {
                filteredData = filteredData.filter(product => product.sku2.toLowerCase().includes(skuValue));
            }
            if (asinValue) {
                filteredData = filteredData.filter(product => product.asin.toLowerCase().includes(asinValue));
            }
            if (availabilityValue) {
                filteredData = filteredData.filter(product => product.availability.toLowerCase().includes(availabilityValue));
            }
            if (leadTimeValue) {
                filteredData = filteredData.filter(product => product.lead_time.toLowerCase().includes(leadTimeValue));
            }
            if (brandValue) {
                filteredData = filteredData.filter(product => product.brand.toLowerCase().includes(brandValue));
            }
            renderTableRows(filteredData, document.getElementById('productTable'));
            atualizarContagemProdutos(filteredData.length);
        })
        .catch(error => console.error("Erro ao aplicar filtros: ", error));
}

function atualizarContagemProdutos(count) {
    document.getElementById('total-produtos').textContent = count;
}

function deleteProduct(sku, element) {
    if (confirm('Tem certeza que deseja excluir este produto?')) {
        fetch(`/produto/${sku}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(() => {
                const row = element.parentNode.parentNode;
                row.parentNode.removeChild(row);
                atualizarContagemProdutos(document.querySelectorAll('#productTable tr').length);
            })
            .catch(error => console.error('Erro ao excluir o produto:', error));
    }
}


// Função para deletar vários produtos selecionados
function deleteSelectedProducts() {
    const selectedCheckboxes = document.querySelectorAll('input[type="checkbox"]:checked');
    const skusToDelete = Array.from(selectedCheckboxes).map(checkbox => checkbox.getAttribute('data-sku'));
    
    if (skusToDelete.length === 0) {
        alert('Nenhum produto selecionado para exclusão.');
        return;
    }
    
    if (!confirm('Tem certeza que deseja excluir os produtos selecionados?')) {
        return;
    }
    
    fetch('/delete-multiple', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ skus: skusToDelete }),
    })
    .then(response => response.json())
    .then(result => {
        alert(result.message);
        fetchProdutosEAtualizarTabela();
    })
    .catch(error => {
        console.error('Erro ao excluir produtos:', error);
    });
}
  
document.getElementById('batch-delete-btn').addEventListener('click', deleteSelectedProducts);  

  // Adicionando um event listener ao botão de exclusão em massa
  document.getElementById('batch-delete-btn').addEventListener('click', deleteSelectedProducts);
  