document.getElementById('upload-csv-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('csv-file');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Por favor, selecione um arquivo CSV.');
        return;
    }

    const formData = new FormData();
    formData.append('csv', file);

    fetch('/upload-csv', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result-message').textContent = data.message;
    })
    .catch(error => {
        console.error('Erro ao fazer upload e excluir ASINs:', error);
        document.getElementById('result-message').textContent = 'Erro ao fazer upload e excluir ASINs.';
    });
});
